
# Employee Tracker using React Router & Node Backend

## Features
- Employee list from backend API
- Dynamic employee details page
- Add employee form
- Context API for state management
- Express CRUD API
- Error handling for invalid routes

## Frontend Setup
```bash
cd client
npm install
npm start
```

## Backend Setup
```bash
cd server
npm install
node server.js
```

## API Routes
- GET /employees
- GET /employees/:id
- POST /employees


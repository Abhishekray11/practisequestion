
const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

let employees = [
  { id: 1, name: "John", role: "Developer" },
  { id: 2, name: "Sara", role: "Designer" }
];

app.get("/employees", (req, res) => {
  res.json(employees);
});

app.get("/employees/:id", (req, res) => {
  const employee = employees.find(
    (e) => e.id === parseInt(req.params.id)
  );
  res.json(employee);
});

app.post("/employees", (req, res) => {
  const newEmployee = {
    id: employees.length + 1,
    name: req.body.name,
    role: req.body.role
  };

  employees.push(newEmployee);
  res.json(newEmployee);
});

app.listen(5000, () => {
  console.log("Server running on port 5000");
});

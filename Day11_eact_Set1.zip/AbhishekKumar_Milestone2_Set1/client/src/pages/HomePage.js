
import { useEffect, useState, useContext } from "react";
import { Link } from "react-router-dom";
import { AppContext } from "../context/AppContext";

function HomePage() {
  const { employees, setEmployees } = useContext(AppContext);
  const [name, setName] = useState("");
  const [role, setRole] = useState("");

  useEffect(() => {
    fetch("http://localhost:5000/employees")
      .then((res) => res.json())
      .then((data) => setEmployees(data));
  }, [setEmployees]);

  const addEmployee = async () => {
    const response = await fetch("http://localhost:5000/employees", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, role })
    });

    const data = await response.json();
    setEmployees([...employees, data]);
    setName("");
    setRole("");
  };

  return (
    <div className="container">
      <h2>Employee List</h2>

      <input
        placeholder="Employee Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />

      <input
        placeholder="Role"
        value={role}
        onChange={(e) => setRole(e.target.value)}
      />

      <button onClick={addEmployee}>Add Employee</button>

      {employees.map((emp) => (
        <div key={emp.id} className="card">
          <h3>{emp.name}</h3>
          <p>{emp.role}</p>
          <Link to={`/employee/${emp.id}`}>View Details</Link>
        </div>
      ))}
    </div>
  );
}

export default HomePage;


import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

function UserDetailPage() {
  const { id } = useParams();
  const [employee, setEmployee] = useState(null);

  useEffect(() => {
    fetch(`http://localhost:5000/employees/${id}`)
      .then((res) => res.json())
      .then((data) => setEmployee(data));
  }, [id]);

  if (!employee) return <h2>Loading...</h2>;

  return (
    <div className="container">
      <h2>Employee Details</h2>
      <p><strong>Name:</strong> {employee.name}</p>
      <p><strong>Role:</strong> {employee.role}</p>
    </div>
  );
}

export default UserDetailPage;

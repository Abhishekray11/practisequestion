
function Navbar() {
  return (
    <nav className="navbar">
      <h2>Employee Tracker</h2>
    </nav>
  );
}

export default Navbar;

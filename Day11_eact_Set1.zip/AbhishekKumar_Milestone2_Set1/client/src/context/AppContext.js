
import { createContext, useState } from "react";

export const AppContext = createContext();

export function AppProvider({ children }) {
  const [employees, setEmployees] = useState([]);

  return (
    <AppContext.Provider value={{ employees, setEmployees }}>
      {children}
    </AppContext.Provider>
  );
}

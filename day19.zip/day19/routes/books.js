const express = require('express');
const router = express.Router();

// In-memory data store array
let books = [
    { id: 1, title: "1984", author: "Orwell" },
    { id: 2, title: "The Alchemist", author: "Coelho" } 
]// 1. GET /books - Returns all books
router.get('/', (req, res) => {
    res.json(books);
});

// 2. POST /books - Adds a new book with Validation Bonus
router.post('/', (req, res) => {
    const { title, author } = req.body;

    // Bonus: Data validation
    if (!title || !author) {
        return res.status(400).json({ error: "Title and Author are required fields." });
    }

    const newBook = {
        id: books.length > 0 ? books[books.length - 1].id + 1 : 1,
        title,
        author
    };

    books.push(newBook);
    res.status(201).json(newBook);
});

// books/:id - Updates book details via Route Parameters
router.put('/:id', (req, res) => {
    const bookId = parseInt(req.params.id); // Used route parameters (req.params)
    const { title, author } = req.body;

    const book = books.find(b => b.id === bookId);

    if (!book) {
        return res.status(404).json({ error: `Book with ID ${bookId} not found.` });
    }

    // Update details if provided 
    if (title) book.title = title;
    if (author) book.author = author;

    res.json({ message: "Book updated successfully", book });
});

//books/:id - Deletes a book
router.delete('/:id', (req, res) => {
    const bookId = parseInt(req.params.id); // Used route parameters (req.params)
    const bookIndex = books.findIndex(b => b.id === bookId);

    if (bookIndex === -1) {
        return res.status(404).json({ error: `Book with ID ${bookId} not found.` });
    }

    // Remove book from in-memory array
    books.splice(bookIndex, 1);
    res.json({ message: `Book with ID ${bookId} successfully deleted.` });
});

// Export the router module
module.exports = router;
const express = require('express');
const app = express();
const bookRouter = require('./routes/books'); // Import modular routing 
const PORT = 4000;

// Global Middlewares
app.use(express.json());

// Challenge 3: Global Logging Middleware (Must come before routes) [cite: 41]
app.use((req, res, next) => {
    console.log(`[${req.method}] ${req.url} - ${new Date().toISOString()}`);
    next();
});

// Challenge 1 & 2 Routes
app.get('/', (req, res) => res.send('Welcome to Express Server')); // [cite: 12]
app.get('/status', (req, res) => res.json({ server: "running", uptime: "OK" })); // [cite: 15]
app.get('/products', (req, res) => { // 
    const productName = req.query.name;
    if (productName) return res.json({ query: productName }); // [cite: 31]
    return res.status(400).send('Please provide a product name'); // [cite: 29]
});

// Challenge 5: Mount Modular Book Routes [cite: 83]
app.use('/books', bookRouter); 

// Challenge 5: 404 Catch-All Route Handling [cite: 84]
app.use((req, res, next) => {
    res.status(404).send("Route not found"); // Expected 404 output [cite: 87]
});

// Challenge 5 Bonus: Centralized Global Error Handler Middleware [cite: 84, 90]
app.use((err, req, res, next) => {
    console.error(err.stack); // Log the stack trace internally for debugging [cite: 90]
    res.status(500).json({ error: "Internal Server Error" }); // Expected output [cite: 90]
});

app.listen(PORT, () => {
    console.log(`Server executing seamlessly at http://localhost:${PORT}`);
});
#   type module  commonjs
process.argv[2] ---------node path at index 2
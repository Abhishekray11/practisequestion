console.log("Node.js Version:", process.version);
console.log("Current File Name:", __filename);
console.log("Current Directory:", __dirname);
console.log("\n");

const interval = setInterval(() => {
    console.log("Welcome to Node.js");
}, 3000);

setTimeout(() => {
    clearInterval(interval);
    console.log("\n");
    console.log("10 seconds reached. Timer stopped");
}, 10000);
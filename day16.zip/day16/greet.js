import moment from 'moment';
const name = process.argv[2];

if (!name) {
    console.log("Please provide a name");
    process.exit(1);
}

const formattedDateTime = moment().format('ddd MMM D YYYY, h:mm A');
console.log(`Hello, ${name}! Today is ${formattedDateTime}`);
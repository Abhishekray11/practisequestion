import figlet from 'figlet';
import chalk from 'chalk';

figlet('HelloNode.js', (err, data) => {
    if (err) {
        console.log('Something went wrong...');
        console.dir(err);
    }
    console.log(chalk.red.bold(data));
});

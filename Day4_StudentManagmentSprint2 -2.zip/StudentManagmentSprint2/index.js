function login(){

    let username = document.getElementById("username").value;

    let password = document.getElementById("password").value;

    if(username === "student" && password === "1234"){

        window.location.href = "welcome.html";

    }
    else{

        document.getElementById("error").innerHTML =
        "Invalid Username or Password";

    }
}

function openMonthly(){

    window.location.href = "monthly.html";

}



let activities = [

    {
        id:1,
        activity:"Create multiplication tables from 12 to 19",
        subject:"Maths"
    },

    {
        id:2,
        activity:"Learn Solar System",
        subject:"Science"
    },

    {
        id:3,
        activity:"Write essay on Nature",
        subject:"English"
    },

    {
        id:4,
        activity:"Practice Algebra",
        subject:"Maths"
    }

];


function showActivities(){

    let subject =
    document.getElementById("subject").value;

    let result =
    document.getElementById("result");

    let output = "";

    for(let item of activities){

        if(item.subject === subject){

            output += `
                <div class="card">

                    <h3>${item.subject}</h3>

                    <p>${item.activity}</p>

                </div>
            `;
        }
    }

    result.innerHTML = output;
}
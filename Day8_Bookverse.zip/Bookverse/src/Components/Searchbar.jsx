import React from "react";

class SearchBar extends React.Component {
  constructor(props) {
    super(props);

    this.inputRef = React.createRef();
  }

  focusInput = () => {
    this.inputRef.current.focus();
  };

  render() {
    return (
      <div className="mb-4">
        <div className="d-flex gap-2">
          <input
            type="text"
            ref={this.inputRef}
            className="form-control"
            placeholder="Search books..."
          />

          <button
            className="btn btn-primary"
            onClick={this.focusInput}
          >
            Focus
          </button>
        </div>
      </div>
    );
  }
}

export default SearchBar;
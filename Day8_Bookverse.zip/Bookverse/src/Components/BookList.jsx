import React from "react";
import BookCard from "./BookCard";

class BookList extends React.Component {

  componentDidMount() {
    console.log("Books loaded successfully!");
  }

  render() {
    const { books, onBookSelect } = this.props;

    return (
      <div className="row">
        {books.map((book) => (
          <div className="col-md-4 mb-4" key={book.id}>
            <BookCard
              title={book.title}
              author={book.author.name}
              image={book.image}
              onSelect={() => onBookSelect(book.author)}
            />
          </div>
        ))}
      </div>
    );
  }
}

export default BookList;
import React from "react";
import PropTypes from "prop-types";

class BookCard extends React.Component {
  render() {
    const { title, author, image, onSelect } = this.props;

    return (
      <div
        className="card h-100 shadow-sm book-card"
        onClick={onSelect}
      >
        <img
          src={image}
          alt={title}
          className="card-img-top"
        />

        <div className="card-body">
          <h5>{title}</h5>
          <p className="text-muted">{author}</p>
        </div>
      </div>
    );
  }
}

BookCard.propTypes = {
  title: PropTypes.string.isRequired,
  author: PropTypes.string.isRequired,
  image: PropTypes.string.isRequired,
  onSelect: PropTypes.func.isRequired,
};

export default BookCard;
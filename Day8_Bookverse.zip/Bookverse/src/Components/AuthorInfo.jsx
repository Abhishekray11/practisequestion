import React from "react";

class AuthorInfo extends React.Component {
  render() {
    const { author } = this.props;

    if (!author) {
      return (
        <div className="alert alert-info mt-4">
          Click a book to view author details.
        </div>
      );
    }
    return (
      <div className="card p-4 mt-4 shadow">
        <h2>{author.name}</h2>

        <p>{author.bio}</p>

        <h4>Top 3 Books</h4>

        <ul>
          {author.topBooks.map((book, index) => (
            <li key={index}>{book}</li>
          ))}
        </ul>
      </div>
    );
  }
}

export default AuthorInfo;
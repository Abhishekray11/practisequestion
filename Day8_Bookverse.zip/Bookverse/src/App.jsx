import React from "react";

import SearchBar from "./components/SearchBar";
import BookList from "./components/BookList";
import AuthorInfo from "./components/AuthorInfo";

class App extends React.Component {

  state = {
    selectedAuthor: null,

    books: [
      {
        id: 1,
        title: "Atomic Habits",
        image:
          "https://images.unsplash.com/photo-1541963463532-d68292c34b19",

        author: {
          name: "James Clear",
          bio: "James Clear writes about habits and self-improvement.",

          topBooks: [
            "Atomic Habits",
            "Habit Journal",
            "Mastering Growth"
          ]
        }
      },

      {
        id: 2,
        title: "Rich Dad Poor Dad",
        image:
          "https://images.unsplash.com/photo-1512820790803-83ca734da794",

        author: {
          name: "Robert Kiyosaki",

          bio: "Robert Kiyosaki is famous for financial education.",

          topBooks: [
            "Rich Dad Poor Dad",
            "Cashflow Quadrant",
            "Rich Kid Smart Kid"
          ]
        }
      },

      {
        id: 3,
        title: "The Alchemist",
        image:
          "https://images.unsplash.com/photo-1495446815901-a7297e633e8d",

        author: {
          name: "Paulo Coelho",

          bio: "Paulo Coelho is known for inspirational novels.",

          topBooks: [
            "The Alchemist",
            "Brida",
            "Eleven Minutes"
          ]
        }
      }
    ]
  };

  handleAuthorSelect = (author) => {
    this.setState({
      selectedAuthor: author
    });
  };

  render() {
    return (
      <div className="container py-5">

        <h1 className="text-center mb-4">
          BookVerse
        </h1>

        <SearchBar />

        <BookList
          books={this.state.books}
          onBookSelect={this.handleAuthorSelect}
        />

        <AuthorInfo
          author={this.state.selectedAuthor}
        />
      </div>
    );
  }
}

export default App;
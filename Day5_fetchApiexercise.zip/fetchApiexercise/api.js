
// API URLs
const POSTS_API = "https://jsonplaceholder.typicode.com/posts";
const TODOS_API = "https://jsonplaceholder.typicode.com/todos";

// DOM Elements
const postsContainer = document.getElementById("posts");
const todosContainer = document.getElementById("todos");
const errorContainer = document.getElementById("error");

// Fetch Posts
async function fetchPosts() {

    try {

        const response = await fetch(POSTS_API);

        // Error Handling
        if (!response.ok) {
            throw new Error("Failed to fetch posts");
        }

        const posts = await response.json();

        displayPosts(posts.slice(0, 10));

    } catch (error) {

        showError(error.message);

    }
}

// Display Posts
function displayPosts(posts) {

    posts.forEach(function(post) {

        const div = document.createElement("div");

        div.classList.add("card");

        div.innerHTML = `
            <h4>${post.title}</h4>
            <p>${post.body}</p>
        `;

        postsContainer.appendChild(div);

    });

}

// Fetch Todos
async function fetchTodos() {

    try {

        const response = await fetch(TODOS_API);

        // Error Handling
        if (!response.ok) {
            throw new Error("Failed to fetch todos");
        }

        const todos = await response.json();

        displayTodos(todos.slice(0, 5));

    } catch (error) {

        showError(error.message);

    }
}

// Display Todos
function displayTodos(todos) {

    todos.forEach(function(todo) {

        const div = document.createElement("div");

        div.classList.add("card");

        div.innerHTML = `
            <p>${todo.title}</p>

            <p class="${todo.completed ? 'completed' : 'pending'}">
                ${todo.completed ? 'Completed' : 'Pending'}
            </p>
        `;

        todosContainer.appendChild(div);

    });

}

// Show Error
function showError(message) {

    errorContainer.innerText = message;

}

// Start Application
fetchPosts();
fetchTodos();
"use strict";
class ContactManager {
    // We store our contacts in a private list (array) 
    contacts = [];
    // Add a new contact to the list [cite: 17]
    addContact(contact) {
        this.contacts.push(contact);
        console.log(`Success: Added ${contact.name}!`);
    }
    // Show all contacts currently in the list [cite: 18]
    viewContacts() {
        return this.contacts;
    }
    // Delete a contact using its ID [cite: 20]
    deleteContact(id) {
        const index = this.contacts.findIndex(c => c.id === id);
        if (index === -1) {
            // If the ID isn't found, show an error [cite: 9]
            console.log(`Error: Contact with ID ${id} not found.`);
        }
        else {
            this.contacts.splice(index, 1);
            console.log(`Success: Contact ${id} deleted.`);
        }
    }
}
const myContacts = new ContactManager();
// 1. Add a contact [cite: 5]
myContacts.addContact({
    id: 101,
    name: "Sam",
    email: "sam@email.com",
    phone: "555-0199"
});
// 2. View the list [cite: 6]
console.log(myContacts.viewContacts());
// 3. Try to delete a contact that doesn't exist to see the error [cite: 10]
myContacts.deleteContact(999);

import { useState } from "react";
import BookCard from "./BookCard";

function BookList() {

  const booksData = [
    {
      id: 1,
      title: "React",
      author: "ABC",
      price: 199,
    },
    {
      id: 2,
      title: "JavaScript",
      author: "DEF",
      price: 199,
    },
    {
      id: 3,
      title: "TypeScript",
      author: "GHI",
      price: 199,
    },
    {
      id: 4,
      title: "HTML & CSS",
      author: "JKL",
      price: 199,
    },
  ];

  const [viewMode, setViewMode] = useState("grid");
  const [search, setSearch] = useState("");

  const filteredBooks = booksData.filter((book) =>
    book.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      <h1> BookVerse</h1>
      <input type="text" placeholder="Search books..." value={search}onChange={(e) => setSearch(e.target.value)}/>
      <div className="buttons">
        <button onClick={() => setViewMode("grid")}>Grid View</button>
        <button onClick={() => setViewMode("list")}> List View</button>
      </div>

      <div className={viewMode === "grid" ? "grid-container" : "list-container"}>

        {filteredBooks.length > 0 ? (
          filteredBooks.map((book) => (
            <BookCard
              key={book.id}
              title={book.title}
              author={book.author}
              price={book.price}
              viewMode={viewMode}
            />
          ))
        ) : (
          <h2>No Books Found</h2>
        )}

      </div>
    </div>
  );
}

export default BookList;
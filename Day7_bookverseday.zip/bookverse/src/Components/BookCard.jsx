function BookCard({ title, author, price, viewMode }) {
  return (
    <div className={viewMode === "grid" ? "book-card" : "book-list"}>
      <h2>{title}</h2>
      <p>Author: {author}</p>
      <h3>₹{price}</h3>
    </div>
  );
}

export default BookCard;
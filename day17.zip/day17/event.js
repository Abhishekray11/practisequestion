const EventEmitter = require('events');
const emits = new EventEmitter();

emits.on('userLoggedIn', (username) => {console.log(`User ${username} logged in.`);});
emits.on('userLoggedOut', (username) => { console.log(`User ${username} logged out.`);});
emits.on('sessionExpired', (username) => {console.log(`Session expired for user ${username}.`);});

const user = "john";

emits.emit('userLoggedIn', user);
emits.emit('userLoggedOut', user);
console.log("Starting 5-second session timer...");
setTimeout(() => {
    emits.emit('sessionExpired', user);
}, 5000);
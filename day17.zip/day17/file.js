const fs = require('fs').promises;
const path = require('path');

async function handleFeedback() {
    const filePath = path.join(__dirname, 'feedback.txt');
    const inputData = "Node.js is awesome!";

    try {
        await fs.writeFile(filePath, inputData, 'utf8');
        console.log("Data written successfully.");
        console.log("Reading file...");
        const fileContent = await fs.readFile(filePath, 'utf8');
        console.log(fileContent);
        
    } catch (error) {
        console.error("An error occurred:", error.message);
    }
}

handleFeedback();
const fs = require('fs').promises;

console.log("Copy operation started...");

// Reading the file and writing to another file using Promises
fs.readFile('input.txt', 'utf8')
    .then((content) => {
        // Passing the same content to the write operation
        return fs.writeFile('output.txt', content);
    })
    .then(() => {
        console.log("File copied successfully!");
    })
    .catch((err) => {
        // Error handling metric
        console.error("An error occurred during the file operation:", err);
    });
const fs = require('fs');
console.log("Program started...");

// Reading the file
fs.readFile('data.txt', 'utf8', (err, data) => {
    if (err) {
        console.error("Error reading file:", err.message);
        return;
    }
    setTimeout(() => {
        console.log("File Content:\n", data);
        console.log("Read operation completed");
    }, 1500);
});
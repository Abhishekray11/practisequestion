const fs = require('fs').promises;

// function for delay operation
// const delay = (e) => 
//     new Promise(resolve => setTimeout(resolve, e));

// delay function
function delay(t) {
    return new Promise(function(resolve) {
        setTimeout(resolve, t);
    });
}


async function copyFileAsync() {
    try {
        console.log("wait for 1 sec...");
        await delay(1000);

        // Read content
        const content = await fs.readFile('input.txt', 'utf8');

        // Write content
        await fs.writeFile('output.txt', content);

        // Confirmation message
        console.log("File copied successfully!");

    } catch (err) {
        // error handling
        console.error("Failed to copy file:", err.message);
    }
}
copyFileAsync();